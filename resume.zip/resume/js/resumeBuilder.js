var bio = {
	"name" : "Jonathan Espitia",
	"role" : "Anthropologist and Baker",
	"contacts" : {
		"mobile" : "631-877-4204",
		"email" : "jon.espitia@gmail.com",
		"twitter" : "jespitia88",
		"github" : "jespitia",
		"location" : "Durham, NC"
	},
	"welcomeMessage" : "Hi, Welcome to my Resume!",
	"skills" : ["Spanish", "Soccer", "Portugeuse", "HTML/CSS", "Baking"],
	"bioPic" : [href="images/bread.jpeg"]
};


var work = {
	"jobs":  [
	{
		"employer" : "UNC Chapel Hill",
		"title" : "Teaching Assistant",
		"location" : "Chapel Hill, NC",
		"dates" : "2015-2017",
		"description" : "Teach anthropology to college level students."
	},
	{
		"employer" : "Taibi Kornbluth Law Group",
		"title" : "Paralegal",
		"location" : "Durham, NC",
		"dates" : "2010-2015",
		"description" : "Assist attorneys with writing and filing legal documents."
	}
	]
};


var projects = {
	"programs": [
	{
		"title": "Supper Club",
		"dates": "2014",
		"description": "Ran a supper club"
	},
	{
		"title": "Peru Project",
		"dates": "2016",
		"description": "Went to Peru"
	}
	]
}


var education = {
	"schools": [
	  {
		"name": "UNC Chapel Hill",
		"location": "Chapel Hill, NC",
		"degree": "Master of Arts",
		"major": "Anthropology"
	  },
	  {
		"name": "Yale University",
		"location": "New Haven, CT",
		"degree": "Bachelor of Arts",
		"major": "Economics"
	  }
	]
}


bio.display = function() {

		var formattedName = HTMLheaderName.replace("%data%", bio.name);
		var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
		var formattedbioPic = HTMLbioPic.replace("%data%", href=bio.bioPic);
		var formattedWelcome = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
		var formattedMobile = HTMLmobile.replace("%data%", bio.contacts.mobile);
		var formattedEmail = HTMLemail.replace("%data%", bio.contacts.email);
		var formattedTwitter = HTMLtwitter.replace("%data%", bio.contacts.twitter);
		var formattedGithub = HTMLgithub.replace("%data%", bio.contacts.github);
		var formattedCity = HTMLlocation.replace("%data%", bio.contacts.location);

		$("#header").prepend(formattedRole);
		$("#header").prepend(formattedName);
		$("#header").append(formattedbioPic);
		$("#header").append(formattedWelcome);
		$("#topContacts").append(formattedMobile);
		$("#topContacts").append(formattedEmail);
		$("#topContacts").append(formattedTwitter);
		$("#topContacts").append(formattedGithub);
		$("#topContacts").append(formattedCity);

if(bio.skills.length > 0) {

	$("#header").append(HTMLskillsStart);

	var formattedSkill = HTMLskills.replace("%data%", bio.skills[0]);
	$("#skills").append(formattedSkill);
	formattedSkill = HTMLskills.replace("%data%", bio.skills[1]);
	$("#skills").append(formattedSkill);
	formattedSkill = HTMLskills.replace("%data%", bio.skills[2]);
	$("#skills").append(formattedSkill);
	formattedSkill = HTMLskills.replace("%data%", bio.skills[3]);
	$("#skills").append(formattedSkill);
	formattedSkill = HTMLskills.replace("%data%", bio.skills[4]);
	$("#skills").append(formattedSkill);
};

};


work.display = function() {

	work.jobs.forEach(function(job) {

		$("#workExperience").append(HTMLworkStart);

		var formattedEmployer = HTMLworkEmployer.replace("%data%", job.employer);
		var formattedTitle = HTMLworkTitle.replace("%data%", job.title);
		var formattedDates = HTMLworkDates.replace("%data%", job.dates);
		var formattedDescription = HTMLworkDescription.replace("%data%", job.description);
		var formattedWorkLocation = HTMLworkLocation.replace("%data%", job.location);
		var formattedEmployerTitle = formattedEmployer + formattedTitle + formattedDates + formattedWorkLocation + formattedDescription;

		$(".work-entry:last").append(formattedEmployerTitle);
		
	});
};

//not sure how to add a different image for each of the projects...

projects.display = function() {

	projects.programs.forEach(function(project) {

		$("#projects").append(HTMLprojectStart);

		var formattedProjectTitle = HTMLprojectTitle.replace("%data%", project.title);
		var formattedProjectDates = HTMLprojectDates.replace("%data%", project.dates);
		var formattedProjectDescription = HTMLprojectDescription.replace("%data%", project.description);
		var formattedProjectImage = HTMLprojectImage.replace("%data%", href="images/MP.jpg");
		var formattedProjectAll = formattedProjectTitle + formattedProjectDates + formattedProjectDescription + formattedProjectImage;

		$(".project-entry:last").append(formattedProjectAll);

	});
};


education.display = function() {

	education.schools.forEach(function(school) {

	$("#education").append(HTMLschoolStart);

	var formattedschoolName = HTMLschoolName.replace("%data%", school.name);
	var formattedschoolDegree = HTMLschoolDegree.replace("%data%", school.degree);
	var formattedschoolLocation = HTMLschoolLocation.replace("%data%", school.location);
	var formattedschoolMajor = HTMLschoolMajor.replace("%data%", school.major);
	var formattedNameandDegree = formattedschoolName + formattedschoolDegree + formattedschoolLocation + formattedschoolMajor;

	$(".education-entry:last").append(formattedNameandDegree);

	});
};


bio.display();
work.display();
projects.display();
education.display();

$("#mapDiv").append(googleMap);




